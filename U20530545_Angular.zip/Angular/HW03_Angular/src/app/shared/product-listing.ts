export interface ProductListing {
    name: string;  

    productTypeName: string;

    description: string;

    price: number;  

    brand: string;  
    
    image: string;                      

}
