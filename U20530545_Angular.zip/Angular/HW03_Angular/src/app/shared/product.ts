export interface Product {
    producttype: number;

    description: string;   

    name: string; 

    brand: number;  
    
    price: number;  
}