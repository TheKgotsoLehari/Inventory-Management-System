export interface User {
    user?: string

    token?: string
}