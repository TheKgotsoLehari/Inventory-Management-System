export interface LoginUser {
    userName: string;
    
    password: string;
}